# InhoudsOpgave

1. [Inleiding](https://github.com/HU-SD-SV2FE-studenten-2022/v2fe-v2a-2/wiki/Inleiding)
2. [Organisatorische context](https://github.com/HU-SD-SV2FE-studenten-2022/v2fe-v2a-2/wiki/Organisatorische-context)
3. [Aanleiding](https://github.com/HU-SD-SV2FE-studenten-2022/v2fe-v2a-2/wiki/Aanleiding)
3.1 [Aanleiding knelpunten](https://github.com/HU-SD-SV2FE-studenten-2022/v2fe-v2a-2/wiki/Aanpak#31-knelpunten)
3.2 [Aanleiding kansen](https://github.com/HU-SD-SV2FE-studenten-2022/v2fe-v2a-2/wiki/Aanpak#31-knelpunten)
4. [Aanpak](https://github.com/HU-SD-SV2FE-studenten-2022/v2fe-v2a-2/wiki/Aanpak)
5. [Ontwerp document](https://github.com/HU-SD-SV2FE-studenten-2022/v2fe-v2a-2/wiki/Ontwerpdocument)


* [Repo for Github Pages](https://github.com/Ryan-Reddy/Ryan-Reddy.github.io)
* [Project Management](https://github.com/orgs/HU-SD-SV2FE-studenten-2022/projects/23)
* [Organisation repo](https://github.com/HU-SD-SV2FE-studenten-2022/v2fe-v2a-2)

---

- [Sidebar](_sidebar)