In het ontwerpdocument wordt technischer ingegaan over hoe ik de structuur voor me zie.

# Wireframes
[POC wireframes alle](https://www.figma.com/file/ovAVWNv8JU3mMJgD2DfDhS/Wireframing-KPN?node-id=0%3A1&t=eUT9jZocTStnWTyb-1)

# Flowcharts
[Reisdata invoeren medewerker](https://www.figma.com/file/7YJytzJUHx5pA2wS9QjfVo/Reisdata-invoeren-flowchart?node-id=0%3A1&t=HJ2SngZ8KyeSLUWX-1)

