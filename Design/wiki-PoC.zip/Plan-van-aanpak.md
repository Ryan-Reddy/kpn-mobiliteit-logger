Globaal gezien is het plan om:
- RxJS te gebruiken om observables te installeren om een dynamisch C02-dashboard te maken
- ViteJs gebruiken om modulair te werken met front end scripts en het overzicht te bewaren in JavaScript moducles
       (Encapsulated, single-responsibility, reusable code)

Een app te maken die multi-platform is,
      Dynamische aanpassing aan schermformaat, gebaseerd op mobiel en desktop.



Data opslag voorlopig via Json bestanden met dummy data te doen, die dmv een tomcat server(HTTP-requests) opgehaald kunnen worden. 



Data die speelt, voor alle medewerkers bij de invoer en inzien van reisdata:
(- ingelogde gebruikersdata)

- datum
- tijd
- km
- kosten
- type vervoer
- privegebruik/zakelijk

Op groot scherm mag dit best een formulier zijn, 
op mobiel moet dit wel verdeeld worden over pagina's
* Non-ambulant Vaste reiskostenvergoeding

* Non-ambulant Vergoeding op declaratiebasis

<img src="https://user-images.githubusercontent.com/90551370/204327978-9e71b6bb-0dde-4bb5-ba0d-a15cba5775e8.png" width="600">

* Ambulant Lease auto
<img src="https://user-images.githubusercontent.com/90551370/204327928-4ed88a7a-6719-42cc-9d8a-acb323085d36.png" width="600">

* Ambulant Mobiliteitsbudget vast
<img src="https://user-images.githubusercontent.com/90551370/204327847-09bef9bf-0aac-4d3b-afc6-89480f23236b.png" width="600">


* Ambulant Mobiliteitsbudget vast/variabel
<img src="https://user-images.githubusercontent.com/90551370/204327897-fd941ce3-0c14-4729-a2b0-d2b2d13c4d5b.png" width="600">



