> KPN (voluit Koninklijke KPN N.V.) is leverancier van [telecommunicatie](https://nl.wikipedia.org/wiki/Telecommunicatie)- en [ICT](https://nl.wikipedia.org/wiki/Informatietechnologie)-diensten en biedt consumenten vaste en [mobiele telefonie](https://nl.wikipedia.org/wiki/Mobiele_telefoon), 
[internet](https://nl.wikipedia.org/wiki/Internet) en [televisie](https://nl.wikipedia.org/wiki/Televisie). 
Voor zakelijke klanten verzorgt KPN complete telecommunicatie- en ICT-oplossingen. 
KPN biedt wereldwijd [wholesale](https://nl.wikipedia.org/wiki/Wholesale_carrier)-netwerkdiensten aan andere operators. [BRON: wikipedia](https://en.wikipedia.org/wiki/KPN)

## Inleiding
De KPN bestaat al sinds 1752 (als Statenpost) en sinds 1893 (als PTT-NL), in heet vanaf 1998 KPN. 

## Onze Missie
KPN wil van Nederland het best verbonden land ter wereld maken.

## De Klanten van de KPN [BRON:](https://www.overons.kpn/nl/het-bedrijf/kpn-in-een-oogopslag)
* Mobiele abonnees 5,669 mln
* Breedband huishoudens en Zakelijk 3,137 mln
* Consumenten huishoudens 3,531 mln
* Vast-mobiele huishoudens 1,496 mln

## Formaat bedrijf en type medewerkers
De KPN is een groot bedrijf met circa 10.000 medewerkers, hiertussen zijn er medewerkers die continu werkgerelateerd reizen, alleen als forenzen of bijvoorbeeld met een speciaal budget voor mobiliteit.


***
