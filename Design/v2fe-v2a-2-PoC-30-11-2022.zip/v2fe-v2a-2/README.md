```
                                         %&                                                    
                                 &&&&&&&&&&&&&&&&&&&&                                          
                               &&&&&&&&(    *&&&&&&&&&&&&@                                     
                             &&&&&&                 &&&&&&&&&&                                 
                            &&&&&                        &&&&&&&@                              
                           &&&&&                            @&&&&&&                            
                          &&&&&                                &&&&&&,                         
                         &&&&&                                   &&&&&&                        
                         &&&&&                                     &&&&&&                      
                         &&&&@                         &&            &&&&&                     
                         &&&&&                       &&&&&&(                                   
                         &&&&&                       &&&&&&                                    
                         &&&&&                                          &&&&&&&&&&&&&@         
                          &&&&&                   //        */          &&&&&&&&&&&&&&&&&&     
                          /&&&&&             &&&&&&&&&    &&&&&&&&&                  @&&&&&&   
                           &&&&&.           &&&&&&&          @&&&&&&                    &&&&&& 
                    &&&#    &%       %&&    &&&&&&            &&&&&&&   &&@               &&&&&
                  &&&&&&&         &&&&&&&   &&&&&&            &&&&&&   @&&&&&&             &&&&
                 &&&&&           @&&&&&      &&&&&&          &&&&&&      %&&&&&            &&&&
                &&&&&             &&&&&@      @&&&&&        &&&&&&       &&&&&            &&&&&
               .&&&&                &&&&&@      &&&&&@     &&&&&      &&&&&&             &&&&& 
               .&&&&                  &&&&&&.                       &&&&&&              &&&&&. 
                &&&&&                                                                  &&&&&,  
                 &&&&&.                    &&&&&&&&&&&&&&&&&&&&&&&&&&.                &&&&&    
                  &&&&&&.                  &&&&&&&&&&&&&&&&&&&&&&&&&&                @&&&&     
                    &&&&&&&                                                          &&&&&     
                       &&&&&&&                                                      &&&&&      
                          &&&&&&&&@                                                &&&&&       
                             @&&&&&&&&&&&                                         #&&&&,       
                                  &&&&&&&&&&&&&&&&&&&&&&&&&&&@                    &&&&@        
                                         &&&&&&&&&&&&&&&&&&&                    &&&&&&         
                                                                 /&&           &&&&&*          
                                                               &&&&&&&&&,  %&&&&&&&            
                                                                  (&&&&&&&&&&&&&%        
                                                               

ooooooooo.                                          ooooooooo.                   .o8        .o8              
`888   `Y88.                                        `888   `Y88.                "888       "888              
 888   .d88' oooo    ooo  .oooo.   ooo. .oo.         888   .d88'  .ooooo.   .oooo888   .oooo888  oooo    ooo
 888ooo88P'   `88.  .8'  `P  )88b  `888P"Y88b        888ooo88P'  d88' `88b d88' `888  d88' `888   `88.  .8'  
 888`88b.      `88..8'    .oP"888   888   888        888`88b.    888ooo888 888   888  888   888    `88..8'   
 888  `88b.     `888'    d8(  888   888   888        888  `88b.  888    .o 888   888  888   888     `888'    
o888o  o888o     .8'     `Y888""8o o888o o888o      o888o  o888o `Y8bod8P' `Y8bod88P" `Y8bod88P"     .8'     
             .o..P'                                                                              .o..P'      
             `Y8P'                                                                               `Y8P'       



                  ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

                                       Archive Trawler (c) Hogeschool Utrecht

                           Jan-'23 :..... RELEASE.DATE .. LICENSE ..........: PIRATE
                                 0 :.......... DISC(S) .. Arch.TYPE ........: Desktop, web, mobile
                JAVA,JFX,Jsc,HTML :.....PROGRAMLANG(S) .. Est. Cost ........: 9999 million


                                           ▀ ▄▀▀▄ ▄▀▀▄ ▄▀▀▄ ▄▀
                  ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀ █ █  ▓ ▓▀   █  ▓ ▀▀▀█ ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
                                           ▀ ▀    ▀     ▀▀   ▀▀                                                         
                                
                                Repo for Github Pages:
                                https://github.com/Ryan-Reddy/Ryan-Reddy.github.io
                                
                                Project Management:
                                https://github.com/orgs/HU-SD-SV2FE-studenten-2022/projects/23
                                
                                Organisation repo:
                                https://github.com/HU-SD-SV2FE-studenten-2022/v2fe-v2a-2
                                
                                Wiki:
                                https://github.com/HU-SD-SV2FE-studenten-2022/v2fe-v2a-2/wiki
                                
                       
                             ▀ ▄▀▀▄ ▄▀   ▓▄▄  ▄▀▀▄ ▓   ▓   ▄▀▀▄ ▄▀▀▄ ▓▄▄  ▄▀▀  ▄▀
                  ▀▀▀▀▀▀▀▀▀▀ █ █  ▓ ▀▀▀█ █  ▄ █▀▀▓ █   █   █  ▓ █  ▓ █  ▄ ▓▀ ▄ ▀▀▀█ ▀▀▀▀▀▀▀▀▀▀
                             ▀ ▀     ▀▀   ▀▀▀ ▀    ▀▀▀ ▀▀▀ ▀     ▀▀   ▀▀▀ ▀▀▀▀  ▀▀

                                De website kan worden bezocht door een gebruiker.
                                Deze is vrij toegankelijk voor iedereen met de juiste link.
                                Om gebruik te maken van de functionaliteit
                                zal een log in vereist zijn.

                                1. Maak een gebruikers-account aan.
                                2. Bevestig het email adres.
                                3. Log in op de website.

                                Van nu af aan kunt u alle functionaliteiten gebruiken zoals
                                - het invullen van reizen
                                - het inzien van eigen reizen
                                - het inzien van eigen uitstoot aan C02
                                - deze data inzien van leden van je eigen team(als management)

                                een gast account is te bereiken zijn via:

                                gebruikersnaam: test@mail.com
                                wachtwoord: password

                               ▄▀▀  ▄▀▀█ ▄▀▀▄ ▓  ▄ ▄▀▀█ ▄▀▀▄ ▄▀▀▄ ▓▄▄  ▄▀▀  ▄▀
                  ▀▀▀▀▀▀▀▀▀▀▀▀ █ ▀▓ █▀▓  █  ▓ █  ▓ █▀▀  █  ▓ █  ▓ █  ▄ ▓▀ ▄ ▀▀▀█ ▀▀▀▀▀▀▀▀▀▀▀▀▀
                                ▀▀    █   ▀▀   ▀▀  ▀    ▀     ▀▀   ▀▀▀ ▀▀▀▀  ▀▀

                                * Ryan van Lil 1818885 (Ryan Reddy, klugook)

                                The project is licensed under PIRATE License(c) [2022]

                  ÜÛÛÜ                                                                   ÜÛÛÜ
                 ²ßßÛÛÛ²   ÜÜ      Ûßß ÛßÛ ÛßÛ Û Û ÛßÛ   ÛßÛ ÛßÛ ßÛß Ûßß Ûßß      ÜÜ   ²ÛÛÛßß²
                 ßÜ  ßÛÛ² ß ßÛ  Ü  ² Û ²ßÜ ² ² ² ² ²ßß   ² ² ² ²  ²  ²ß  ßß²  Ü  Ûß ß ²ÛÛß  Üß
                      ÛÛÛ²Ü ÜÛÛÜ²Ü ßßß ß ß ßßß ßßß ß     ß ß ßßß  ß  ßßß ßßß Ü²ÜÛÛÜ Ü²ÛÛÛ
                    ÜÛ²ÛÛÛÛÛÛÛßßÛÛÛÛÛÛ²Ü  ÜÛÛßÛÜÜ  ßÜÜ   ÜÜß  ÜÜÛßÛÛÜ  Ü²ÛÛÛÛÛÛßßÛÛÛÛÛÛÛ²ÛÜ
                   Ûß ÜÛÛßßß      ßßÛÛÛ²  ÛÛÜ  ßß²ÛÜ ÛÛ ÛÛ ÜÛ²ßß  ÜÛÛ  ²ÛÛÛßß      ßßßÛÛÜ ßÛ
                    ß ÛÛÜ  Ü      Ü ÜÛß    ßÛß     ßÛÛß ßÛÛß     ßÛß    ßÛÜ Ü      Ü  ÜÛÛ ß
                      ßÛÛÛß        ßß         ß                 ß         ßß        ßÛÛÛß

                                  THE ONE-man-Band are currently looking for

                               ÜÛÛÜ                                         ÜÛÛÜ
                              ²ÛÛ ßß  Ü    nothing but competition!     Ü  ßß ÛÛ²
                               ²ÛÛÜ Ü²ß²                               ²ß²Ü ÜÛÛ²
                             ÜÛÛÛÛÛÛ²ß     Greetings to ALEX & JOS       ß²ÛÛÛÛÛÛÜ

                            ²ÛÛß  ßÛÛÜÜ ÜÜ                           ÜÜ ÜÜÛÛß  ßÛÛ²
                            ÛÛ   Ü ßÛ²ÛÛ²ßÛÜÛßÛÜÜ   Ü  Ü  Ü   ÜÜÛßÛÜÛß²ÛÛ²Ûß Ü   ÛÛ
                            ßÛÛÜÜß Ü Û Û Ü ßÜ  ßß²ÛÜ Û ² Û ÜÛ²ßß  Üß Ü Û Û Ü ßÜÜÛÛß
                              ßß    ß   ß     Üß   ßß  ß  ßß   ßÜ     ß   ß    ßß
                                               ßÛ²Ü AVG^HUI  Ü²Ûß
                                                 Üß 05/2022 ßÜ
                                                ²      Ü      ²
                                                 ß   ²ßÜß²   ß
                                                 Ü  Û  ²  Û  Ü
                                                  ßß       ßß
```
