package database.webservices.dto;

/**
 * Een DTO met daarin een email om op te zoeken.
 *
 * @Attribute email; Een door de gebruiker ingevoerde email.
 */
public class ResetAccount {
    public String email;
}
