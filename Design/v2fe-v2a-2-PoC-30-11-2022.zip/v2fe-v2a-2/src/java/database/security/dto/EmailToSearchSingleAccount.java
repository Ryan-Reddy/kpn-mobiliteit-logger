package database.security.dto;

public class EmailToSearchSingleAccount {
    public String email;
}
