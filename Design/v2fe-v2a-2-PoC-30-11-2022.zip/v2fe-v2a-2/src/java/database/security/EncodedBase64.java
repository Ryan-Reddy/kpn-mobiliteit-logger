package database.security;

public class EncodedBase64 {
    private String base64str;

    public EncodedBase64() {
    }

    public EncodedBase64(String base64str) {
        this.base64str = base64str;
    }

    public String getBase64str() {
        return base64str;
    }

    public void setBase64str(String base64str) {
        this.base64str = base64str;
    }
}
