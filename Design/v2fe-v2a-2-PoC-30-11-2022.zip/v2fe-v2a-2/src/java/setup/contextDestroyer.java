package setup;

import database.model.User;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class contextDestroyer implements ServletContextListener {

    /**
     * contextInitialized
     * Deze functie runt automatisch bij het opstarten van het programma/server.
     * Voert automatisch een data persistentie handeling uit.
     */
    @Override
    public void contextInitialized(ServletContextEvent sce) {
//        try {
        System.out.println("contextInitialized");
        System.out.println("TODO load database here");

//            PersistanceManager.loadFromAzure();  // data inladen van azure container
//        } catch (IOException e) {
//            System.out.println("catching IOException");
//            e.printStackTrace();
//        } catch (ClassNotFoundException e) {
//            System.out.println("catching ClassNotFoundException");
//            e.printStackTrace();
//        }

        // DUMMYDATA: /** NIET VERWIJDEREN */
        new User("Coyote", "test@mail.com", "password");
        new User("Ryan", "ryanreddy@hotmail.com", "password");
        new User("TickTock", "aldous@harding.com", "Wilde");
        new User("CrazyDiamond", "syd@barrett.com", "Floyd");
//        new Archief("amsarchief","https://webservices.picturae.com/genealogy/person?apiKey=eb37e65a-eb47-11e9-b95c-60f81db16c0e&page=1&q={naam}&rows=1000&sort=score%20desc");
//        new Archief("openarchief","https://api.openarch.nl/1.0/records/search.json?name={naam}&lang=nl&number_show=100&sort=1&start=0&archive");
//        new User( "pickItUpLikeItsCold", "snoop@log.bomb","Ryan");
//        new Archief("test","");
        // DUMMYDATA: /** NIET VERWIJDEREN */

    }

    /**
     * contextDestroyed
     * Deze functie runt automatisch bij het afsluiten van het programma/server.
     * Voert automatisch een data persistentie handeling uit.
     */
    @Override
    public void contextDestroyed(ServletContextEvent sce) {

        /* Overige code, bijvoorbeeld om naar Azure te schrijven! */
        System.out.println("Context destroyed, saving everything to azure-storage");
//        try {
        System.out.println("TODO save database here");
//            PersistanceManager.uploadToAzure("communityblob",PersistanceManager.communityContainer);  // data ophalen van de azure container
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        /* Dit deel ruimt op na afsluiten van scherm: */
//        Schedulers.shutdownNow();
//        HttpResources.disposeLoopsAndConnectionsLater(Duration.ZERO, Duration.ZERO).block();
    }
}
